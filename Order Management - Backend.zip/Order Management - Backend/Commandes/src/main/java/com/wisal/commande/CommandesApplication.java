package com.wisal.commande;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;

import com.wisal.commande.entities.Commande;
import com.wisal.commande.service.CommandeService;

@SpringBootApplication
public class CommandesApplication implements CommandLineRunner {
	
	@Autowired
	CommandeService commandeService;

	public static void main(String[] args) {
		SpringApplication.run(CommandesApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
	}

	
}

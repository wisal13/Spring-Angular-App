package com.wisal.commande.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wisal.commande.entities.Client;
import com.wisal.commande.entities.Commande;
import com.wisal.commande.repos.CommandeRepository;

@Service
public class CommandeServiceImpl implements CommandeService {

	@Autowired
	CommandeRepository commandeRepository;
	
	@Override
	public Commande saveCommande(Commande comnd) {
		return commandeRepository.save(comnd);
	}

	@Override
	public Commande updateCommande(Commande comnd) {
		return commandeRepository.save(comnd);
	}

	@Override
	public void deleteCommande(Commande comnd) {
		commandeRepository.delete(comnd);
		
	}

	@Override
	public void deleteCommandeById(Long idCommande) {
		commandeRepository.deleteById(idCommande);
		
	}

	@Override
	public Commande getCommande(Long idCommande) {
		return commandeRepository.findById(idCommande).get();
	}

	@Override
	public List<Commande> getAllCommandes() {
		return commandeRepository.findAll();
	}

	@Override
	public List<Commande> findByEtat(String etat) {
		return commandeRepository.findByEtat(etat);
	}

	@Override
	public List<Commande> findByEtatContains(String etat) {
		return commandeRepository.findByEtatContains(etat);
	}

	@Override
	public List<Commande> findByEtatPrixTotal(String etat, Double prixTotal) {
		return commandeRepository.findByEtatPrixTotal(etat, prixTotal);
	}

	@Override
	public List<Commande> findByClient(Client client) {
		return commandeRepository.findByClient(client);
	}

	@Override
	public List<Commande> findByClientIdCl(Long idCl) {
		return commandeRepository.findByClientIdCl(idCl);
	}

	@Override
	public List<Commande> findByOrderByEtatAsc() {
		return commandeRepository.findByOrderByEtatAsc();
	}

	@Override
	public List<Commande> trierCommandesEtatPrixTotal() {
		return commandeRepository.trierCommandesEtatPrixTotal();
	}

}

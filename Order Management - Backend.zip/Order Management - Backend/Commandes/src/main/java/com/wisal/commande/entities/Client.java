package com.wisal.commande.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Client {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idCl;
	private String nomCl;
	private String adresseCl;
	private int numCl;
	
	
	@OneToMany(mappedBy = "client")
	@JsonIgnore
	private List<Commande> commandes;

	public Client() {}

	public Client(String nomCl, String adresseCl, int numCl, List<Commande> commandes) {
		super();
		this.nomCl = nomCl;
		this.adresseCl = adresseCl;
		this.numCl = numCl;
		this.commandes = commandes;
	}

	public Long getIdCl() {
		return idCl;
	}

	public void setIdCl(Long idCl) {
		this.idCl = idCl;
	}

	public String getNomCl() {
		return nomCl;
	}

	public void setNomCl(String nomCl) {
		this.nomCl = nomCl;
	}

	public String getAdresseCl() {
		return adresseCl;
	}

	public void setAdresseCl(String adresseCl) {
		this.adresseCl = adresseCl;
	}

	public int getNumCl() {
		return numCl;
	}

	public void setNumCl(int numCl) {
		this.numCl = numCl;
	}

	public List<Commande> getCommandes() {
		return commandes;
	}

	public void setCommandes(List<Commande> commandes) {
		this.commandes = commandes;
	}
	
	
	

}

package com.wisal.commande.entities;


import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class Commande {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idCommande;
	private Double prixTotal;
	private String etat;
	private Date dateCreation;	
	
	@ManyToOne
	private Client client;
	
	public Commande() {
		super();
	}
	
	public Commande(String etat, Double prixTotal, Date dateCreation) {
		super();
		this.etat = etat;
		this.prixTotal = prixTotal;
		this.dateCreation = dateCreation;
	}

	public Long getIdCommande() {
		return idCommande;
	}
	public void setIdCommande(Long idCommande) {
		this.idCommande = idCommande;
	}
	

	public String getEtat() {
		return etat;
	}

	
	public void setEtat(String etat) {
		this.etat = etat;
	}
	
	
	public Double getPrixTotal() {
		return prixTotal;
	}
	public void setPrixTotal(Double prixTotal) {
		this.prixTotal = prixTotal;
	}
	
	public Date getDateCreation() {
		return dateCreation;
	}
	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}

	@Override
	public String toString() {
		return "Commande [idCommande=" + idCommande + ", prixTotal=" + prixTotal + ", etat =" + etat +  ", dateCreation=" + dateCreation + "]";
	}

	
	

}

package com.wisal.commande.service;

import java.util.List;

import com.wisal.commande.entities.Client;
import com.wisal.commande.entities.Commande;


public interface CommandeService {

	Commande saveCommande(Commande comnd);
	Commande updateCommande(Commande comnd);
	void deleteCommande(Commande comnd);
	void deleteCommandeById(Long idCommande);
	Commande getCommande(Long idCommande);
	List<Commande> getAllCommandes();
	
	List<Commande> findByEtat(String etat);
	List<Commande> findByEtatContains(String etat);
	List<Commande> findByEtatPrixTotal (String etat, Double prixTotal);
	List<Commande> findByClient (Client client);
	List<Commande> findByClientIdCl(Long idCl);
	List<Commande> findByOrderByEtatAsc();
	List<Commande> trierCommandesEtatPrixTotal();

	
}

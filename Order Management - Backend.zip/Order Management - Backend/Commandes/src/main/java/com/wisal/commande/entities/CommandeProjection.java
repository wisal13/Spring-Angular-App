package com.wisal.commande.entities;

import org.springframework.data.rest.core.config.Projection;

@Projection(name = "etatCom", types = { Commande.class })
public interface CommandeProjection {
	public String getNomCommande();


}

package com.wisal.commande.restcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.wisal.commande.entities.Commande;
import com.wisal.commande.service.CommandeService;


@RestController
@RequestMapping("/api")
@CrossOrigin
public class CommandeRESTController {
	@Autowired
	CommandeService commandeService;
	
	@RequestMapping(path = "all",method = RequestMethod.GET)
	public List<Commande> getAllCommandes() {
		return commandeService.getAllCommandes();
	}
	
	@RequestMapping(value="/{idCommande}",method = RequestMethod.GET)
	public Commande getCommandeById(@PathVariable("idCommande") Long id) {
		return commandeService.getCommande(id);
	 }
	
	@RequestMapping(method = RequestMethod.POST)
	public Commande createCommande(@RequestBody Commande commande) {
		return commandeService.saveCommande(commande);
	}
	
	@RequestMapping(method = RequestMethod.PUT)
	public Commande updateCommande(@RequestBody Commande commande) {
		return commandeService.updateCommande(commande);
	}
	
	@RequestMapping(value="/{idCommande}",method = RequestMethod.DELETE)
	public void deleteCommande(@PathVariable("idCommande") Long id)
	{
		commandeService.deleteCommandeById(id);
	}

	@RequestMapping(value="/comndscl/{idCl}",method = RequestMethod.GET)
	public List<Commande> getCommandesByClId(@PathVariable("idCl") Long idCl) {
		return commandeService.findByClientIdCl(idCl);
	}



}

package com.wisal.commande.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.wisal.commande.entities.Client;
import com.wisal.commande.entities.Commande;

@RepositoryRestResource(path = "rest")
public interface CommandeRepository extends JpaRepository<Commande, Long> {

	List<Commande> findByEtat(String etat);
	List<Commande> findByEtatContains(String etat);
	
	@Query("select c from Commande c where c.etat like %?1 and c.prixTotal > ?2")
	List<Commande> findByEtatPrixTotal (String etat, Double prixTotal);
	
	@Query("select c from Commande c where c.client = ?1")
	List<Commande> findByClient (Client client);
	
	List<Commande> findByClientIdCl(Long idCl);
	
	List<Commande> findByOrderByEtatAsc();
	
	@Query("select c from Commande c order by c.etat ASC, c.prixTotal DESC")
	List<Commande> trierCommandesEtatPrixTotal ();



	 
}

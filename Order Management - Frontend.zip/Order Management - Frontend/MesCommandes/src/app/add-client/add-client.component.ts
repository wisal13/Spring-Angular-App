import { ClientService } from './../services/client.service';
import { Component, OnInit } from '@angular/core';
import { Client } from '../model/client';

@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.css']
})

export class AddClientComponent implements OnInit {

  newClient = new Client();

  message :string;

  constructor(private ClientService: ClientService) { }

  ngOnInit(): void {
  }

  addClient(){
   // console.log(this.newClient);
    this.ClientService.ajouterClient(this.newClient);
    this.message = "Client " + this.newClient.idCl + " ajouté avec succès !";

    }

}
 
export class Client {
    idCl? : number;
    nomCl : string;
    adresseCl : string;
    numCl : number;
    }
    
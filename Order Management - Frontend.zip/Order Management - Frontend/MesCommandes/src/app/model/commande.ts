import { Client } from './client';
export class Commande {
    idCommande : number;
    prixTotal : number;
    etat : string;
    dateCreation : Date ;
    client : Client ; 
}
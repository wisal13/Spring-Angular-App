import { Client } from './../model/client';
import { AuthService } from './../services/auth.service';
import { Component, OnInit } from '@angular/core';
import { Commande } from '../model/commande';
import { CommandeService } from '../services/commande.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-commandes',
  templateUrl: './commandes.component.html'
})
export class CommandesComponent implements OnInit {

  commandes : Commande[]; //un tableau de commandes
  nomCl : Client["nomCl"];
  clients : Client[];

  constructor(private commandeService: CommandeService, private router :Router,
               public authService: AuthService) { 
    //this.commandes = commandeService.listeCommande();

  }

  ngOnInit(): void {
    this.commandeService.listeCommande().subscribe(comnd => {
      console.log(comnd);
      this.commandes = comnd;
      });
    
  }

 /*  supprimerCommande(comnd : Commande)
  {
      //console.log(comnd);
      let conf = confirm("Etes-vous sûr ?");
      if (conf)
        this.commandeService.supprimerCommande(comnd);
  } */

  supprimerCommande(comnd : Commande)
    {
    let conf = confirm("Etes-vous sûr ?");
    if (conf)
    this.commandeService.supprimerCommande(comnd.idCommande).subscribe(() => {
    console.log("commande supprimé");
    this.SuprimerCommandeDuTableau(comnd);
    });
    /* this.router.navigate(['commandes']).then(() => {
    window.location.reload();
    }); */ 
    }

    SuprimerCommandeDuTableau(comnd : Commande) {
      this.commandes.forEach((cur, index) => {
      if(comnd.idCommande=== cur.idCommande) {
      this.commandes.splice(index, 1);
      }
      });
      }


}

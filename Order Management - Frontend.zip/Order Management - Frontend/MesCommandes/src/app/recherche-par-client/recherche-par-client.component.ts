import { Component, OnInit } from '@angular/core';
import { Client } from '../model/client';
import { Commande } from '../model/commande';
import { CommandeService } from '../services/commande.service';

@Component({
  selector: 'app-recherche-par-client',
  templateUrl: './recherche-par-client.component.html',
  styles: [
  ]
})
export class RechercheParClientComponent implements OnInit {

  commandes : Commande[] =[]; //un tableau de Commande
  clients : Client[];
  IdClient : number;

  constructor(private commandeService: CommandeService) { }

  ngOnInit(): void {
    this.clients = this.commandeService.listeClients();
  }

  onChange() {
    // console.log(this.IdClient);
     this.commandes =  this.commandeService.rechercherParClient(this.IdClient);
     console.log(this.commandes);
     
     }

}

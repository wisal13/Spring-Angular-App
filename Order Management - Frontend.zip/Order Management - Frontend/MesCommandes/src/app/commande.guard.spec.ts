import { TestBed } from '@angular/core/testing';

import { CommandeGuard } from './commande.guard';

describe('CommandeGuard', () => {
  let guard: CommandeGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(CommandeGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});

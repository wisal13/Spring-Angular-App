import { Client } from './../model/client';
import { Injectable } from '@angular/core';
import { Commande } from '../model/commande';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

const httpOptions = {
  headers: new HttpHeaders( {'Content-Type': 'application/json'} )
  };
  

@Injectable({
  providedIn: 'root'
})
export class CommandeService {

  apiURL: string = 'http://localhost:8081/commandes/api/all';
  apiURLL: string = 'http://localhost:8081/commandes/api/';
  apiURLLL: string = 'http://localhost:8081/commandes/api';


  client = new Client();
  commande = new Commande();
  commandes : Commande[]; //un tableau de commandes
  clients : Client[]; 
  commandesRecherche : Commande[];

  constructor(private http : HttpClient,
              private authService: AuthService) {

    this.clients = [
      {idCl : 1, nomCl : "Wissal Talbi", adresseCl : "Tunis", numCl : 58874112},
      {idCl : 2, nomCl : "Hounayda Khzemi", adresseCl : "Borj Cédria", numCl : 95268273},
      {idCl : 3, nomCl : "Sourour Boughanmi", adresseCl : "Ben Arous", numCl : 25789412}

    ];
    /*
    this.commandes = [
      {idCommande : 1, prixTotal : 500.2, etat : "Livré", dateCreation : new Date("10/24/2021")},
      {idCommande : 2, prixTotal : 85.7, etat : "Annulé", dateCreation : new Date("10/24/2021")},
      {idCommande : 3, prixTotal : 50.4, etat : "Expedié", dateCreation : new Date("10/24/2021")}

    ];  */
   }

   listeClients():Client[] {
    return this.clients;
    }

    consulterClient(id:number): Client{    
      this.client =  this.clients.find(cl => cl.idCl  == id);
        return this.client;
     }

  listeCommande(): Observable<Commande[]>{
    //return this.http.get<Commande[]>(this.apiURL);
    let jwt = this.authService.getToken();
    jwt = "Bearer " + jwt;
    let httpHeaders = new HttpHeaders({ "Authorization": jwt })
    return this.http.get<Commande[]>(this.apiURLL + "all", { headers: httpHeaders }
    );

    }

 /* ajouterCommande(commande : Commande){
    this.commandes.push(commande);
  }*/

  ajouterCommande( comnd: Commande): Observable<Commande>{
    //return this.http.post<Commande>(this.apiURLL, comnd, httpOptions);
    let jwt = this.authService.getToken();
    jwt = "Bearer " + jwt;
    let httpHeaders = new HttpHeaders({ "Authorization": jwt })
    return this.http.post<Commande>(this.apiURLL, comnd, { headers: httpHeaders });
    }
    

    supprimerCommande(id : number) {
      const url = `${this.apiURLLL}/${id}`;
      let jwt = this.authService.getToken();
      jwt = "Bearer " + jwt;
      let httpHeaders = new HttpHeaders({ "Authorization": jwt })
      return this.http.delete(url, { headers: httpHeaders });
     // return this.http.delete(url, httpOptions);
      }

  /*  consulterCommande(id:number): Commande{
      return this.commandes.find(p => p.idCommande == id);
      //return this.commande;
      } */

      consulterCommande(id: number): Observable<Commande> {
        const url = `${this.apiURLLL}/${id}`;
        //return this.http.get<Commande>(url);
        let jwt = this.authService.getToken();
        jwt = "Bearer " + jwt;
        let httpHeaders = new HttpHeaders({ "Authorization": jwt })
        return this.http.get<Commande>(url, { headers: httpHeaders });

        }

    updateCommande(cm :Commande) : Observable<Commande>
    {
   // return this.http.put<Commande>(this.apiURLLL, cm, httpOptions);
      let jwt = this.authService.getToken();
      jwt = "Bearer " + jwt;
      let httpHeaders = new HttpHeaders({ "Authorization": jwt })
      return this.http.put<Commande>(this.apiURLLL, cm, { headers: httpHeaders });
    }

    trierCommandes(){
      this.commandes = this.commandes.sort((n1,n2) => {
      if (n1.idCommande > n2.idCommande) {
      return 1;
      }
      if (n1.idCommande < n2.idCommande) {
      return -1;
      }
      return 0;
      });
      }

      rechercherParClient(idCl: number): Commande[]{
        this.commandesRecherche = [];
       
        this.commandes.forEach((cur, index) => {
         if(idCl == cur.client.idCl) {
             console.log("cur "+cur);
            this.commandesRecherche.push(cur);
             }
       });
       return this.commandesRecherche;
       }

}
